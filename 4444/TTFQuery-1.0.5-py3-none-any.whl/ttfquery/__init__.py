"""Fonttools package for querying and sorting system fonts"""
__version__ = "1.0.5"

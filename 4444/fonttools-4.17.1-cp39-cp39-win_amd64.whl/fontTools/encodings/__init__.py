"""Empty __init__.py file to signal Python this directory is a package."""

from fontTools.misc.py23 import *
